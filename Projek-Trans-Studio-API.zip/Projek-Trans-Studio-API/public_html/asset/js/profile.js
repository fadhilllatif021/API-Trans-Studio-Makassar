$("#stark .nav-icon").click(function () {
    $("#stark").addClass("animate-out");
    $("#martell").addClass("animate-out");
  });
  
  $("#martell .nav-icon").click(function () {
    $("#martell").addClass("animate-out-again");
    $("#baratheon").addClass("animate-out");
  });
  