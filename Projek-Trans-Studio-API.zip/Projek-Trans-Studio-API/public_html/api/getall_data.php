<?php

    // header hasil berbentuk json
    header("Content-Type:application/json");

    $header = apache_request_headers();
    $key = $header['key'];

    // tangkap medode akses
    $methode = $_SERVER['REQUEST_METHOD'];

    // Koneksi database
    $servername = "localhost";
    $username   = "root";
    $password   = "";
    $dbname     = "transstudio";

    // Koneksi ke DB
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Cek user
    $sql = "SELECT * FROM user WHERE key_token='$key'";
    $user = $conn->query($sql);

    if ($user->num_rows > 0) {

        // Cek metode
        if ($methode == 'GET') {

            $result['status'] = [
                "code" => 200,
                "description" => 'Request Key Valid'
            ];

            // Buat Query
            $sql = "SELECT * FROM hiburan";

            // Eksekusi Query
            $hasil_query = $conn->query($sql);

            // Masukkan ke Array result
            $result['results'] = $hasil_query->fetch_all(MYSQLI_ASSOC);

        } else{

            $result['status'] = [
                "code" => 400,
                "description" => 'Request not Valid'
            ];
        }

    }else{
        $result['status'] = [
            "code" => 400,
            "description" => 'API Key/Token not Valid'
        ];
    }

    // Tampilkan data dalam format JSON
    echo json_encode($result);


?>