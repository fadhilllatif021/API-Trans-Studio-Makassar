<?php

	// Header hasil berbentuk json
	header("Content-Type:application/json");

	$methode = $_SERVER['REQUEST_METHOD'];

	$result = array();

	// Cek metode
	if ($methode == 'POST') {

		// Pengecekan Parameter
		if(isset($_POST['nama']) AND isset($_POST['kategori']) AND isset($_POST['deskripsi']) AND isset($_POST['jumlah_barang']) AND isset($_POST['biaya']) AND isset($_POST['waktu'])){
			
			// Tangkap Parameter
            $nama = $_POST['nama'];
            $kategori = $_POST['kategori'];
            $deskripsi = $_POST['deskripsi'];
            $jumlah_barang = $_POST['jumlah_barang'];
            $biaya = $_POST['biaya'];
            $waktu = $_POST['waktu'];

			// Tangkap Foto
			$foto_tmp = $_FILES['foto']['tmp_name'];
			$nama_foto = $_FILES['foto']['name'];

			// Pindahkan dari tmp location ke lokasi permanen
			move_uploaded_file($foto_tmp, 'foto/'.$nama_foto);

			// Jika metode sesuai
			$result['status'] = [
				"code" => 200,
				"description" => '1 Data Inserted'
			];

			// Koneksi database
			$servername = "localhost";
			$username	= "root";
			$password	= "";
			$dbname		= "transstudio";

			// Membuat koneksi
			$conn = new mysqli($servername, $username, $password, $dbname);

			// Buat Query
			$sql = "INSERT INTO hiburan (nama, kategori, deskripsi, jumlah_barang, biaya, waktu, foto)
                                    VALUES('$nama', '$kategori', '$deskripsi', '$jumlah_barang', '$biaya', '$waktu', '$nama_foto')";
			// Eksekusi Query
			$conn->query($sql);

			// Masukkan ke Array result
			$result['results'] = [
                "nama" => $nama,
                "kategori" => $kategori,
                "deskripsi" => $deskripsi,
                "jumlah_barang" => $jumlah_barang,
                "biaya" => $biaya,
                "waktu" => $waktu,
				"foto" => $nama_foto
			];

		}else{

			// Jika metode tidak sesuai
			$result['status'] = [
				"code" => 400,
				"description" => 'Parameter Invalid'
			];

		}

	} else{

		// Jika metode tidak sesuai
		$result['status'] = [
			"code" => 400,
			"description" => 'Method not Valid'
		];
	}

	// Tampilkan data dalam format JSON
	echo json_encode($result);

?>