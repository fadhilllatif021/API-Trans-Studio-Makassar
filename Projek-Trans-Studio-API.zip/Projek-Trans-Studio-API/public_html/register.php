<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with Creative Design landing page.">
    <meta name="author" content="Devcrud">
    <title>Trans Studio | Liburan Seru Di Trans Studio</title>

    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">

    <!-- Bootstrap + Creative Design main styles -->
     <link rel="stylesheet" href="assets/css/creative-design1.css">

</head>
<body>
    <div class="container">
        <div class="login">
            <form action="signup_aksi.php" method="post" enctype="multipart/form-data">
                <h1>Sign Up</h1>
                <hr>
                    <?php if (isset($_GET['error'])) { ?>
                         <p class="error"><?php echo $_GET['error']; ?></p>
                    <?php } ?>

                    <?php if (isset($_GET['success'])) { ?>
                         <p class="success"><?php echo $_GET['success']; ?></p>
                    <?php } ?>

               <label style="margin-top: 10px;" for="">Email</label>
               <?php if (isset($_GET['email'])) { ?>
                    <input type="Email" 
                           name="email" 
                           placeholder=""
                           value="<?php echo $_GET['email']; ?>"><br>
               <?php }else{ ?>
                    <input type="Email" 
                           name="email" 
                           placeholder=""><br>
               <?php }?>

               <label for="">Username</label>
               <!-- <input type="text" name="name" placeholder=""> -->
               <?php if (isset($_GET['name'])) { ?>
                    <input type="text" 
                           name="name" 
                           placeholder=""
                           value="<?php echo $_GET['name']; ?>"><br>
               <?php }else{ ?>
                    <input type="text" 
                           name="name" 
                           placeholder=""><br>
               <?php }?>

                <label for="">Password</label>
                <input type="Password" name="password" placeholder="">
                <input type="submit" class="btn btn-red" name="submit" value="Register"></button>
                <p>
                    <a href="login.php">Login Now!</a>
                </p>
            </form>
        </div>
        <div class="right">
            <img src="assets/imgs/logo.png" alt="Transstudio">
        </div>
    </div>

</body>
</html>