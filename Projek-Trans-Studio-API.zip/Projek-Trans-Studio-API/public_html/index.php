<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with Creative Design landing page.">
    <meta name="author" content="Devcrud">
    <title>Trans Studio | Liburan Seru Di Trans Studio</title>

    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">

    <!-- Bootstrap + Creative Design main styles -->
	<link rel="stylesheet" href="assets/css/creative-design.css">

</head>
<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home">
    
    <!-- Page Navbar -->
    <nav id="scrollspy" class="navbar page-navbar navbar-light navbar-expand-md fixed-top" data-spy="affix" data-offset-top="20">
        <div class="container">
            <img src="assets/imgs/logo.png" width="80px" alt="About Us">
            <!-- <a class="navbar-brand" href="assets/imgs/logo.png"><strong class="text-primary">Creative</strong> <span class="text-dark">Design</span></a> -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#apidocumentation">API Documentation</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#testmonial">Founder</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                    <li class="nav-item ml-md-4">
                        <a class="nav-link btn btn-warning" href="login.php">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav><!-- End of Page Navbar -->   

    <!-- Page Header -->
    <header id="home" class="header">
        <div class="overlay"></div>
        <div class="header-content">
            <p>Wahana Liburan Seru Keluarga</p>
            <h6>TRANS STUDIO MAKASSAR</h6> 
        </div>      
    </header><!-- End of Page Header -->    
    
    <!-- About Section -->
    <section id="about">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h1>About</h1></div>
                <div class="content">
                    <h5 class="title mb-3">Trans Studio Makassar.</h5>
                    <!-- row -->
                    <div class="row">
                        <div class="col">
                            <p>Trans Studio Makassar merupakan salah-satu wahana wisata indoor terbesar yang ada di Indonesia. Konsep yang modern, nyaman, beragam keseruan dalam satu kawasan, adalah daya pikat dari Trans Studio Makassar.</p>
                            <p><b>Wahana hiburan dan juga permainan dengan memiliki nilai edukasi yang tinggi untuk anak-anak.</b></p>                        
                            <p>Trans Studio Makassar ini telah menjawab sudah kebutuhan masyarakat yang mengusung tempat permainan indoors maka akan terasa lebih nyaman karena tidak akan kuatir akan terjadinya perubahan cuaca, entah itu di waktu hujan maupun di waktu panas.</p>
                        </div>
                        <div class="col">
                            <p>Perlu anda ketahui bahwa Trans Studio Makassar ini merupakan sebuah taman hiburan yang berada dalam ruangan terbesar kedua setelah tempat Trans Studio Bandung yang berada di Kota Bandung.</p>
                            <p>Trans Studio Makassar yang berdiri di atas lahan seluas 2,7 Hektar beralamat di Jl. H.M Dg. Patompo - Metro Tanjung Bunga, Makassar.</p>
                            <p>Trans Studio Makasar dilengkapi dengan 22 wahana permainan yang sangat atraktif dan telah berhasil menarik perhatian banyak wisatawan. Mulai dari Studio Central, Lost City, Magic Corner, putar petir, sepeda terbang, rimba express, safari trick, si bolang, Karosel, Esia, Balon House, Ayun ombak, Angin Beliung, Mini Boom-boom car, trans city theateer, hollywood bumper car, dan lain sebagainya.</p>
                        </div>
                    </div><!-- End of Row -->                   
                    <a href="https://www.nativeindonesia.com/trans-studio-makassar/" style="color: #F85C70; font-style: italic;">Read More...</a>
                </div>
            </div><!-- End of About Wrapper -->         
        </div>  <!-- End of Container-->        
     </section><!--End of Section -->


    <!-- section -->
    <section>
        <!-- Container -->
        <div class="container">
            <!-- row -->
            <div class="row justify-content-between align-items-center">
                <div class="col-md-6">
                    <div class="img-wrapper">
                        <div class="after"></div>
                        <img src="assets/imgs/img2.png" class="w-100" alt="About Us">
                    </div>
                </div>
                <div class="col-md-5">
                    <h6 class="title mb-3">Studio Central.</h6>
                    
                    <p>Studio yang satu ini memang sudah di desain semenarik mungkin layaknya kawasan yang ada di Hollywood. Di sini anda akan disuguhi berbagai artis ternama yang ada di Hall Of Frame.</p>
                    <p>Bukan hanya itu saja, anda juga akan disuguhi pemandangan indah berupa arsitektur Hollywood dengan gaya tahun 60-an sehingga anda berasa sedang berlibur di sana.</p>
                    <a href="https://www.nativeindonesia.com/trans-studio-makassar/" style="color: #FAD02C; font-style: italic;">Read More...</a>
                </div>
            </div>
            <!-- End of Row -->
        </div>  
        <!-- End of Container -->
    </section><!-- End of Section -->   

    <!-- section -->
    <section>
        <!-- Container -->
        <div class="container">
            <!-- Row -->
            <div class="row justify-content-between align-items-center">                
                <div class="col-md-5">
                    <h6 class="title mb-3">Lost City.</h6>
                    <p>Studio ini menyajikan sebuah petualangan seru yang bisa anda dapatkan di studio ini. Siapka diri anda untuk berpetualang nantinya</p>
                    <p>Pada kawasan ini tentu saja anda akan menempuh suatu perjalanan yang begitu hebat sekali. Anda seakan memasuki sebuah hutan rimba yang ada dalam safari track. Anda pun bisa melakukan penjelajahan ala petualangan.</p>
                    <a href="https://www.nativeindonesia.com/trans-studio-makassar/" style="color: #F85C70; font-style: italic;">Read More...</a>

                </div>
                <div class="col-md-6">
                    <div class="img-wrapper">
                        <div class="after right"></div>
                        <img src="assets/imgs/img3.png" class="w-100" alt="About Us">
                    </div>                      
                </div>
            </div><!-- End of Row -->           
        </div><!-- End of Container-->      
    </section><!-- End of Section -->
    

    <!-- Features Section -->
    <section class="has-bg-img" id="features">
        <div class="overlay"></div>
        <!-- Button trigger modal -->
        <a data-toggle="modal" href="#exampleModalCenter">
            <i></i>
        </a>

        <!-- Modal -->
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                     <iframe width="100%" height="450px" class="border-0" 
                    src="https://youtu.be/ZcbWzfJaOOk">
                    </iframe>
                </div>
            </div>
        </div><!-- End of Modal -->     
    </section><!-- End of features Section -->  

    <!-- Section -->
    <section>
        <!-- Container -->
        <div class="container">
            <!-- Row -->
            <div class="row justify-content-between align-items-center">
                <div class="col-md-6">
                    <div class="img-wrapper">
                        <div class="after"></div>
                        <img src="assets/imgs/img4.png" class="w-100" alt="About us">
                    </div>
                </div>
                <div class="col-md-5">
                    <h6 class="title mb-3">Magic Corner.</h6>
                    
                    <p>Studio yang satu ini memang menghadirkan sebuah tema keajaiban. Banyak sekali atraksi magic yang bisa anda saksikan di dalam studio ini.</p>
                    <p>Pastinya perjalanan yang akan anda lakukan nanti bisa menyihir anda seolah-olah merasa yakin dengan apapun yang ada di depan mata anda.</p>
                    <a href="https://www.nativeindonesia.com/trans-studio-makassar/" style="color: #47D8E0; font-style: italic;">Read More...</a>
                </div>
            </div><!-- End of Row -->           
        </div><!-- End of Container-->      
    </section><!-- End of Section -->  

    <!-- API Documentation Section -->
    <section class="mt-5" id="apidocumentation">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h2>API DOCUMENTATION</h2></div>
                <div class="content">
                    <h2 class="title mb-3 ml-1">Dokumentasi API Trans Studio.</h2>
                    <!-- row -->
                    <div class="row ml-1">
                        <p>Dokumentasi ini menjelaskan cara mengakses layanan API Trans Studio Makassar yang ditujukan untuk para developer. Para developer tinggal login maka otomatis akan mendapatkan API Key untuk mengakses data.</p>
                        <p><b>Data tiap hiburan yang ada di Trans Studio Makassar dapat lebih mudah di akses.</b></p>                        
                        <p>Data yang dapat diakses berupa nama hiburan, kategori, deskripsi, jumlah barang, biaya, waktu, serta foto dari tiap hiburan.</p>
                        <p> <b>Note:</b> API Key digunakan untuk mengakses data bagi para user yang ingin mengakses database, didapatkan setelah register dan harus digunakan dengan bijak sehingga tidak merugikan pihak Trans Studio Makassar dan pihak lain manapun.</p>

                        <div class="col">
                    </div><!-- End of Row -->           
                </div>
            </div><!-- End of About Wrapper -->         
        </div>  <!-- End of Container-->       
     </section><!--End of Section --> 

    <!-- Testmonial Section -->
    <section class="text-center pt-5" id="testmonial">
        <!-- Container -->
        <div class="container">
            <h3 class="mt-5 mb-5 pb-5">Founder</h3>
            <!-- Row -->
            <div class="row">
                <div class="col-sm-10 col-md-4 m-auto">
                    <div class="testmonial-wrapper">
                        <img src="assets/imgs/fala.jpg" alt="Client Image">
                        <h6 class="title mb-3">Muh Fadhil Latif</h6>
                        <p>Seorang Mahasiswa dengan NIM 42519012 dari kelas 3A TKJ biasa di panggil Fala. Dia hobinya berkelana serta memiliki cita-cita menjadi komisaris Perusahaan NASA.</p>
                    </div>
                </div>
                <div class="col-sm-10 col-md-4 m-auto">
                    <div class="testmonial-wrapper">
                        <img src="assets/imgs/ika.jpg" alt="Client Image">
                        <h6 class="title mb-3">Nurul Syafika</h6>
                        <p>Seorang Mahasiswa dengan NIM 42519018 dari kelas 3A TKJ yang memiliki cita-cita menjadi Direktur E-Commerce Shopee.</p>
                    </div>
                </div>
                <div class="col-sm-10 col-md-4 m-auto">
                    <div class="testmonial-wrapper">
                        <img src="assets/imgs/yadi.jpg" alt="Client Image">
                        <h6 class="title mb-3">M. Yadi Nugraha</h6>
                        <p>Seorang Mahasiswa dengan NIM 42519009 dari kelas 3A TKJ yang hobinya main game dan tak pernah terkalahkan yang memiliki cita-cita mempunyai saham 1% dari Perusahaan Tencent.</p>
                    </div>
                </div>
            </div><!-- end of Row -->           
        </div><!-- End of Cotanier -->  
    </section><!-- End of Testmonial Section -->

    <!-- Contact Section -->
    <section id="contact" class="text-center">
        <!-- container -->
        <div class="container">
            <h1>CONTACT US</h1>
            <p class="mb-5">If you have some Questions or need Help! Please Contact Us! <br></p>
            
            <!-- Contact form -->
            <form class="contact-form col-md-11 col-lg-9 mx-auto">
                <div class="form-row">
                    <div class="col form-group">
                        <input type="text" class="form-control" placeholder="Name">
                    </div>
                    <div class="col form-group">
                        <input type="email" class="form-control" placeholder="Email">
                    </div>
                </div>
                <div class="form-group">
                    <textarea name="" id="" cols="30" rows="5" class="form-control" placeholder="Your Message"></textarea>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary btn-block" value="Send Message">
                </div>
            </form><!-- End of Contact form -->         
        </div><!-- End of Container-->      
    </section><!-- End of Contact Section -->   

    <!-- Section -->
    <section class="pb-0">
        <!-- Container -->
        <div class="container">
            <!-- Pre footer -->
            <div class="pre-footer">
                <ul class="list">
                    <li class="list-head">
                        <h6 class="font-weight-bold">ABOUT US</h6>
                    </li>
                    <li class="list-body">
                        <p>Kelas D4 3A TKJ Angkatan 19.</p>
                    </li>
                </ul>
                <ul class="list">
                    <li class="list-head">
                        <h6 class="font-weight-bold">CONTACT INFO</h6>
                    </li>
                    <li class="list-body">
                        <p>082253241165</p>
                        <p><i class="ti-location-pin"></i> Makassar, Kota Daeng</p>
                        <p><i class="ti-email"></i> tkj19pnup@gmail.com</p>
                    </li>
                </ul> 
            </div><!-- End of Pre footer -->            

            <!-- foooter -->
            <footer class="footer">            
                <p>Copyright <script>document.write(new Date().getFullYear())</script> &copy; <a href="https://github.com/fadhilllatif021">3A TKJ</a></p>
            </footer><!-- End of Footer-->  
            
        </div><!--End of Container -->      
    </section><!-- End of Section -->

    <!-- core  -->
    <script src="assets/vendors/jquery/jquery-3.4.1.js"></script>
    <script src="assets/vendors/bootstrap/bootstrap.bundle.js"></script>

    <!-- bootstrap affix -->
    <script src="assets/vendors/bootstrap/bootstrap.affix.js"></script>

    <!-- Creative Design js -->
    <script src="assets/js/creative-design.js"></script>

</body>
</html>
