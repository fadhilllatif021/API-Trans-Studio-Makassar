<?php
    //header hasil berbentuk json
    header("Content-Type:application/json");

    //metode
    $method = $_SERVER['REQUEST_METHOD'];

    $result = array();

    if($method=='DELETE'){

        //menangkap data PUT dengan parse
        parse_str(file_get_contents("php://input"), $_DELETE);

        //cek parameter
        if(isset($_DELETE['id']) AND isset($_DELETE['nama'])){
            
            //tangkap parameter
            $id = $_DELETE['id'];
            $nama = $_DELETE['nama'];

            $result['status'] = [
                "code" => 200,
                "description" => 'Data Delete'
            ];
    
            // Database Connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "transstudio";
    
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // query
            $sql = "DELETE FROM hiburan WHERE id='$id' AND nama='$nama'";
            $conn->query($sql);
            // array to result
            $result['results'] = [
                "id" => $id,
                "nama" => $nama
            ];
    
        }else{
            $result['status'] = [
                "code" => 400,
                "description" => 'Invalid Parameter'
            ];
        }
    }else{
        $result['status'] = [
            "code" => 400,
            "description" => 'Failed to Delete'
        ];
    }

    //tampilkan data dengan json
    echo json_encode($result);
?>
