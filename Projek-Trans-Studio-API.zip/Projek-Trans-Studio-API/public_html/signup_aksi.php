<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['email']) && isset($_POST['name'])
    && isset($_POST['password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$email = validate($_POST['email']);
	$name = validate($_POST['name']);
	$password = validate($_POST['password']);


	if (empty($email)) {
		header("Location: register.php?error=Email is required");
	    exit();
	}else if(empty($name)){
        header("Location: register.php?error=Username is required");
	    exit();
	}
	else if(empty($password)){
        header("Location: register.php?error=Password is required");
	    exit();
	}

	else{

		// hashing the password
        $token = md5($name.$password);

	    $sql = "SELECT * FROM user WHERE user_name='$name' ";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			header("Location: register.php?error=The username is taken try another");
	        exit();
		}else {
           $sql2 = "INSERT INTO user (email, user_name, password, key_token) VALUES('$email','$name', '$password', '$token')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
           	 header("Location: login.php?success=Your account has been created successfully");
	         exit();
           }else {
	           	header("Location: register.php?error=unknown error occurred");
		        exit();
           }
		}
	}
	
}else{
	header("Location: register.php");
	exit();
}