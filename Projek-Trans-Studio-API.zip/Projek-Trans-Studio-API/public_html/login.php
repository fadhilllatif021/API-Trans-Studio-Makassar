<!DOCTYPE html>
<html>

     <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
          <meta name="description" content="Start your development with Creative Design landing page.">
          <meta name="author" content="Devcrud">
          <title>Trans Studio | Liburan Seru Di Trans Studio</title>

          <!-- font icons -->
          <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">

          <!-- Bootstrap + Creative Design main styles -->
          <link rel="stylesheet" href="assets/css/creative-design1.css">

          <title>LOGIN</title>
          <link rel="stylesheet" type="text/css" href="style.css">
     </head>

     <body>
          <div class="container">
               <div class="login">

                    <form action="login_aksi.php" method="POST">
                         <h1>Login</h1>
                         <hr>
                         <p>Welcome Back!</p>
                              <?php if (isset($_GET['error'])) { ?>
                                   <p style="color: red" class="error"><?php echo $_GET['error']; ?></p>
                              <?php } ?>
                         <label for="">Username</label>
                         <input type="text" name="uname" placeholder="">
                         <label for="">Password</label>
                         <input type="Password" name="password" placeholder="">
                         <button type="submit">Login</button>
                         <p>
                              <a href="register.php">Sign Up Now!</a>
                         </p>   
                    </form>
                    
               </div>
               <div class="right">
                    <img src="assets/imgs/logo.png" alt="Transstudio">
               </div>
          </div>
     </body>

</html>