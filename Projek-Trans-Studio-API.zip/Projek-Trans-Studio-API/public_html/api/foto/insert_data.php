<?php
    //header hasil berbentuk json
    header("Content-Type:application/json");
    
    //metode
    $method = $_SERVER['REQUEST_METHOD'];

    $result = array();

    if($method=='POST'){

        //cek parameter
        if(isset($_POST['nama']) AND isset($_POST['kategori']) AND isset($_POST['deskripsi']) AND isset($_POST['jumlah_barang']) AND isset($_POST['biaya']) AND isset($_POST['waktu'])){
            
            //tangkap parameter
            $nama = $_POST['nama'];
            $kategori = $_POST['kategori'];
            $deskripsi = $_POST['deskripsi'];
            $jumlah_barang = $_POST['jumlah_barang'];
            $biaya = $_POST['biaya'];
            $waktu = $_POST['waktu'];

            $result['status'] = [
                "code" => 200,
                "description" => 'Data Inserted'
            ];
    
            // Database Connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "transstudio";
    
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // query
            $sql = "INSERT INTO hiburan (nama, kategori, deskripsi, jumlah_barang, biaya, waktu)
                                    VALUES('$nama', '$kategori', '$deskripsi', '$jumlah_barang', '$biaya', '$waktu')";
            $conn->query($sql);
            // array to result
            $result['results'] = [
                "nama" => $nama,
                "kategori" => $kategori,
                "deskripsi" => $deskripsi,
                "jumlah_barang" => $jumlah_barang,
                "biaya" => $biaya,
                "waktu" => $waktu
            ];
    
        }else{
            $result['status'] = [
                "code" => 400,
                "description" => 'Invalid Parameter'
            ];
        }
    }else{
        $result['status'] = [
            "code" => 400,
            "description" => 'Failed to Insert'
        ];
    }

    //tampilkan data dengan json
    echo json_encode($result);
?>