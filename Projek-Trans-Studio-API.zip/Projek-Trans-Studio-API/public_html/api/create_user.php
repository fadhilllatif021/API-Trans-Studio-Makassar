<?php
    //header hasil berbentuk json
    header("Content-Type:application/json");
    
    //metode
    $method = $_SERVER['REQUEST_METHOD'];

    $result = array();

    if($method=='POST'){

        //cek parameter
        if(isset($_POST['email']) AND isset($_POST['username']) AND isset($_POST['password'])){
            
            //tangkap parameter
            $email = $_POST['email'];
            $name = $_POST['username'];
            $pass = $_POST['password'];

            $result['status'] = [
                "code" => 200,
                "description" => 'Success Create'
            ];
    
            // Database Connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "transstudio";
    
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // query
            $sql = "INSERT INTO user (email,username, password) VALUES('$email', '$name', '$pass')";
            $conn->query($sql);
            // array to result
            $result['results'] = [
                "email" => $email,
                "username" => $name
            ];
    
        }else{
            $result['status'] = [
                "code" => 400,
                "description" => 'Invalid to Regis'
            ];
        }
    }else{
        $result['status'] = [
            "code" => 400,
            "description" => 'Failed to Regis'
        ];
    }

    //tampilkan data dengan json
    echo json_encode($result);
?>