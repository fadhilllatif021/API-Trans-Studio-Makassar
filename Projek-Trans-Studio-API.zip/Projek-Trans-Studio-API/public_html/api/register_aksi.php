<?php

	// Header hasil berbentuk json
	header("Content-Type:application/json");

	$methode = $_SERVER['REQUEST_METHOD'];

	$result = array();

	// Cek metode
	if ($methode == 'POST') {

		// Pengecekan Parameter
		if (isset($_POST['email']) AND isset($_POST['name']) AND isset($_POST['pass'])) {
			
			// Tangkap Parameter
			$email = $_POST['email'];
			$name = $_POST['name'];
			$pass = $_POST['pass'];

			// Jika metode sesuai
			$result['status'] = [
				"code" => 200,
				"description" => 'Success Create'
			];

			// Koneksi database
			$servername = "localhost";
			$username	= "root";
			$password	= "";
			$dbname		= "transstudio";

			// Membuat koneksi
			$conn = new mysqli($servername, $username, $password, $dbname);

			// Buat Query
			$sql = "INSERT INTO user (email, name, pass) VALUES('$email', '$name', '$pass')";

			// Eksekusi Query
			$conn->query($sql);

			// Masukkan ke Array result
			$result['results'] = [
				"email" 	 => $email,
				"username" 	 => $name,
				"password" => $pass
			];

		}else{

			// Jika metode tidak sesuai
			$result['status'] = [
				"code" => 400,
				"description" => 'Invalid to Regis'
			];

		}

	} else{

		// Jika metode tidak sesuai
		$result['status'] = [
			"code" => 400,
			"description" => 'Method not Valid'
		];
	}

	// Tampilkan data dalam format JSON
	echo json_encode($result);

?>