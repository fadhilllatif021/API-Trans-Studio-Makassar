<?php
        //header hasil berbentuk json
        header("Content-Type:application/json");
    
        //metode
        $method = $_SERVER['REQUEST_METHOD'];
    
        $result = array();
    
        if($method=='PUT'){

            //menangkap data PUT dengan parse
            parse_str(file_get_contents("php://input"), $_PUT);
    
            //cek parameter
            if(isset($_PUT['nama']) AND isset($_PUT['kategori']) AND isset($_PUT['deskripsi']) AND isset($_PUT['jumlah_barang']) AND isset($_PUT['biaya']) AND isset($_PUT['waktu'])
            AND isset($_PUT['id'])) {
                
                //tangkap parameter
                $nama = $_PUT['nama'];
                $kategori = $_PUT['kategori'];
                $deskripsi = $_PUT['deskripsi'];
                $jumlah_barang = $_PUT['jumlah_barang'];
                $biaya = $_PUT['biaya'];
                $waktu = $_PUT['waktu'];
                $id = $_PUT['id'];
    
                $result['status'] = [
                    "code" => 200,
                    "description" => 'Data Update'
                ];
        
                // Database Connection
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "transstudio";
        
                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // query
                $sql = "UPDATE hiburan SET nama='$nama',
                                            kategori='$kategori',
                                            deskripsi='$deskripsi',
                                            jumlah_barang='$jumlah_barang',
                                            biaya='$biaya',
                                            waktu='$waktu'
                                            WHERE id='$id'";
                $conn->query($sql);
                // array to result
                $result['results'] = [
                    "nama" => $nama,
                    "kategori" => $kategori,
                    "deskripsi" => $deskripsi,
                    "jumlah_barang" => $jumlah_barang,
                    "biaya" => $biaya,
                    "waktu" => $waktu
                ];
        
            }else{
                $result['status'] = [
                    "code" => 400,
                    "description" => 'Invalid Parameter'
                ];
            }
        }else{
            $result['status'] = [
                "code" => 400,
                "description" => 'Failed to Update'
            ];
        }
    
        //tampilkan data dengan json
        echo json_encode($result);
?>

