<?php

    session_start();
    include "db_conn.php";
    
    $key = '';
    $sql = "SELECT * FROM user WHERE id=".$_SESSION['id'];
    $result = $conn->query($sql);

    if ($result->num_rows > 0 ){
        $row = mysqli_fetch_assoc($result);
        $key = $row['key_token'];
    }else{
        $key = "Kamu Belum Memliki Token";
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with Creative Design landing page.">
    <meta name="author" content="Devcrud">
    <title>Trans Studio | Liburan Seru Di Trans Studio</title>

    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">

    <!-- Bootstrap + Creative Design main styles -->
	<link rel="stylesheet" href="assets/css/creative-design.css">

</head>
<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home">
    
    <!-- Page Navbar -->
    <nav id="scrollspy" class="navbar page-navbar navbar-light navbar-expand-md fixed-top" data-spy="affix" data-offset-top="20">
        <div class="container">
            <img src="assets/imgs/logo.png" width="80px" alt="About Us">
            <!-- <a class="navbar-brand" href="assets/imgs/logo.png"><strong class="text-primary">Creative</strong> <span class="text-dark">Design</span></a> -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">API Documentation</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#apikey">API KEY</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#get">Get</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#insert">Insert</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#update">Update</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#delete">Delete</a>
                    </li>
                    <li class="nav-item ml-md-4">
                        <a class="nav-link btn btn-warning" href=""><?php echo $_SESSION['user_name']; ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav><!-- End of Page Navbar -->   

    <!-- Page Header -->
    <header id="home" class="header">
        <div class="overlay"></div>
        <div class="header-content">
            <p>API DOCUMENTATION</p>
            <h6>TRANS STUDIO MAKASSAR</h6> 
        </div>      
    </header><!-- End of Page Header -->    
    
    <!-- About Section -->
    <section id="about">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h2>API DOCUMENTATION</h2></div>
                <div class="content">
                    <h2 class="title mb-3 ml-1">Dokumentasi API Trans Studio.</h2>
                    <!-- row -->
                    <div class="row ml-1">
                        <p>Dokumentasi ini menjelaskan cara mengakses layanan API Trans Studio Makassar yang ditujukan untuk para developer. Para developer tinggal login maka otomatis akan mendapatkan API Key untuk mengakses data.</p>
                        <p><b>Data tiap hiburan yang ada di Trans Studio Makassar dapat lebih mudah di akses.</b></p>                        
                        <p>Data yang dapat diakses berupa nama hiburan, kategori, deskripsi, jumlah barang, biaya, waktu, serta foto dari tiap hiburan.</p>
                        <p> <b>Note:</b> API harus digunakan dengan bijak sehingga tidak merugikan pihak Trans Studio Makassar dan pihak lain manapun.</p>

                        <div class="col">
                    </div><!-- End of Row -->           
                </div>
            </div><!-- End of About Wrapper -->         
        </div>  <!-- End of Container-->        
     </section><!--End of Section -->

     <!-- API Key Section -->
    <section id="apikey">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h1>KEY</h1></div>
                <div class="content">
                    <h2 class="title mb-3 ml-1">API KEY Trans Studio.</h2>
                    <!-- row -->
                    <div class="row ml-1">
                        <div>
                        <p style=""><?php echo $key;?></p>                           
                        </div>                  

                    </div><!-- End of Row -->           
                </div>
            </div><!-- End of About Wrapper -->         
        </div>  <!-- End of Container-->        
    </section><!--End of Section -->
    
    <!-- Get All Data Section -->
    <section id="get">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h4>Get Data</h4></div>
                <div class="content">

                    <!-- Request Get All Data -->
                    <h2 class="title mb-3 ml-1">Request Get All Data.</h2>
                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">URL</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">URL</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td>GET</td>
                                        <td>http://localhost:7882/transstudio/public_html/api/getall_data.php</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">Parameter</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">Parameter</th>
                                        <th scope="col">Tipe</th>
                                        <th scope="col">Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td scope="row">GET/HEAD</td>
                                        <td>Key</td>
                                        <td>String</td>
                                        <td>API Key</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <!-- Response Get All Data -->
                    <h6>Response</h6>
                        
                    <p>Response Success</p>
                    <div class="docs-code-block">
                        <!-- ** Embed github code starts ** -->
                        <script src="https://gist.github.com/fadhilllatif021/97f2c52f764b6183454c5a8decb09380.js"></script>
                        <!-- ** Embed github code ends ** -->
                    </div><!--//docs-code-block-->

                    <!-- END Response Get All Data -->
                    <!-- END Request Get All Data -->
                              
                </div>
            </div><!-- End of About Wrapper -->         
        </div>  <!-- End of Container-->        
     </section><!--End of Section -->

    <!-- Get Data By Nama Section -->
    <section id="get">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h4>Get Data</h4></div>
                <div class="content">

                    <!-- Request Search by Nama -->
                    <h2 class="title mt-5 mb-3 ml-1">Request Search by Nama.</h2>
                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">URL</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">URL</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td>GET</td>
                                        <td>http://localhost:7882/transstudio/public_html/api/getonedata_nama.php?nama=sepeda touring</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">Parameter</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">Parameter</th>
                                        <th scope="col">Tipe</th>
                                        <th scope="col">Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td scope="row">GET/HEAD</td>
                                        <td>Key</td>
                                        <td>String</td>
                                        <td>API Key</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">GET</td>
                                        <td>nama</td>
                                        <td>String</td>
                                        <td>nama hiburan</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <!-- Response Get All Data -->
                    <h6>Response</h6>
                        
                    <p>Response Success</p>
                    <div class="docs-code-block">
                        <!-- ** Embed github code starts ** -->
                        <script src="https://gist.github.com/fadhilllatif021/c5e987f8de93b424eab7a75ded9a88b3.js"></script>
                        <!-- ** Embed github code ends ** -->
                    </div><!--//docs-code-block-->

                    <!-- END Response Get All Data -->
                    <!-- END Request Get All Data -->
                              
                </div>
            </div><!-- End of About Wrapper -->         
        </div>  <!-- End of Container-->        
     </section><!--End of Section --> 

    <!-- Get Data By Kategori Section -->
    <section id="get">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h4>Get Data</h4></div>
                <div class="content">

                    <!-- Request Search by Nama -->
                    <h2 class="title mt-5 mb-3 ml-1">Request Search by Kategori.</h2>
                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">URL</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">URL</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td>GET</td>
                                        <td>http://localhost:7882/transstudio/public_html/api/getonedata_kategori.php?kategori=musik</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">Parameter</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">Parameter</th>
                                        <th scope="col">Tipe</th>
                                        <th scope="col">Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td scope="row">GET/HEAD</td>
                                        <td>Key</td>
                                        <td>String</td>
                                        <td>API Key</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">GET</td>
                                        <td>kategori</td>
                                        <td>String</td>
                                        <td>kategori</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <!-- Response Get All Data -->
                    <h6>Response</h6>
                        
                    <p>Response Success</p>
                    <div class="docs-code-block">
                        <!-- ** Embed github code starts ** -->
                        <script src="https://gist.github.com/fadhilllatif021/84b233dbfdd9e05647356fad18227b8a.js"></script>
                        <!-- ** Embed github code ends ** -->
                    </div><!--//docs-code-block-->

                    <!-- END Response Get All Data -->
                    <!-- END Request Get All Data -->
                              
                </div>
            </div><!-- End of About Wrapper -->         
        </div>  <!-- End of Container-->        
     </section><!--End of Section --> 
    
    <!-- Insert Data Section -->
    <section id="insert">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h3>Insert Data</h3></div>
                <div class="content">

                    <!-- Request Search by Nama -->
                    <h2 class="title mt-5 mb-3 ml-1">Insert Data dan Upload File Foto.</h2>
                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">URL</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">URL</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td>POST</td>
                                        <td>http://localhost:7882/transstudio/public_html/api/insert_data.php</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">Parameter</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">Parameter</th>
                                        <th scope="col">Tipe</th>
                                        <th scope="col">Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td scope="row">POST</td>
                                        <td>nama</td>
                                        <td>String</td>
                                        <td>nama hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">POST</td>
                                        <td>kategori</td>
                                        <td>String</td>
                                        <td>Kategori tiap hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">POST</td>
                                        <td>deskripsi</td>
                                        <td>String</td>
                                        <td>Penjelasan singkat mengenai hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">POST</td>
                                        <td>foto</td>
                                        <td>String</td>
                                        <td>Foto dari tiap barang/hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">POST</td>
                                        <td>biaya</td>
                                        <td>Int</td>
                                        <td>Biaya sewa setiap hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">POST</td>
                                        <td>waktu</td>
                                        <td>String</td>
                                        <td>Waktu penyewaan alat hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">POST</td>
                                        <td>jumlah barang</td>
                                        <td>Int</td>
                                        <td>Jumlah barang yang sedang tak terpakai</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <!-- Response Get All Data -->
                    <h6>Response</h6>
                        
                    <p>Response Success</p>
                    <div class="docs-code-block">
                        <!-- ** Embed github code starts ** -->
                        <script src="https://gist.github.com/fadhilllatif021/c82d1c515fc4e792f76389bda3f0019e.js"></script>
                        <!-- ** Embed github code ends ** -->
                    </div><!--//docs-code-block-->

                    <!-- END Response Get All Data -->
                    <!-- END Request Get All Data -->
                              
                </div>
            </div><!-- End of About Wrapper -->   
        </div>  <!-- End of Container-->        
     </section><!--End of Section -->

     <!-- Section -->

    <!-- Update Data Section -->
    <section id="update">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h5>Update Data</h5></div>
                <div class="content">

                    <!-- Request Search by Nama -->
                    <h2 class="title mt-5 mb-3 ml-1">Update Data.</h2>
                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">URL</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">URL</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td>PUT</td>
                                        <td>http://localhost:7882/transstudio/public_html/api/update_data.php</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">Parameter</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">Parameter</th>
                                        <th scope="col">Tipe</th>
                                        <th scope="col">Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td scope="row">PUT</td>
                                        <td>id</td>
                                        <td>Int</td>
                                        <td>id tiap hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">PUT</td>
                                        <td>nama</td>
                                        <td>String</td>
                                        <td>nama hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">PUT</td>
                                        <td>kategori</td>
                                        <td>String</td>
                                        <td>Kategori tiap hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">PUT</td>
                                        <td>deskripsi</td>
                                        <td>String</td>
                                        <td>Penjelasan singkat mengenai hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">PUT</td>
                                        <td>foto</td>
                                        <td>String</td>
                                        <td>Foto dari tiap barang/hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">PUT</td>
                                        <td>biaya</td>
                                        <td>String</td>
                                        <td>Biaya sewa setiap hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">PUT</td>
                                        <td>waktu</td>
                                        <td>String</td>
                                        <td>Waktu penyewaan alat hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">PUT</td>
                                        <td>jumlah barang</td>
                                        <td>String</td>
                                        <td>Jumlah barang yang sedang tak terpakai</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <!-- Response Get All Data -->
                    <h6>Response</h6>
                        
                    <p>Response Success</p>
                    <div class="docs-code-block">
                        <!-- ** Embed github code starts ** -->
                        <script src="https://gist.github.com/fadhilllatif021/1b1706cc343d2db258440614747d4991.js"></script>
                        <!-- ** Embed github code ends ** -->
                    </div><!--//docs-code-block-->

                    <!-- END Response Get All Data -->
                    <!-- END Request Get All Data -->
                              
                </div>
            </div><!-- End of About Wrapper -->   
        </div>  <!-- End of Container-->        
     </section><!--End of Section -->
     <!-- Section -->

    <!-- Delete Data Section -->
    <section id="delete">
        <!-- Container -->
        <div class="container">
            <!-- About wrapper -->
            <div class="about-wrapper">
                <div class="after"><h5>Delete Data</h5></div>
                <div class="content">

                    <!-- Request Search by Nama -->
                    <h2 class="title mt-5 mb-3 ml-1">Delete Data.</h2>
                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">URL</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">URL</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td>DELETE</td>
                                        <td>http://localhost:7882/transstudio/public_html/api/delete_data.php</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <div class="about-five-tab">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-who-tab" data-bs-toggle="tab" data-bs-target="#nav-url"
                                    type="button" role="tab" aria-controls="nav-url" aria-selected="true">Parameter</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-url" role="tabpanel" aria-labelledby="nav-who-tab">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">Method</th>
                                        <th scope="col">Parameter</th>
                                        <th scope="col">Tipe</th>
                                        <th scope="col">Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td scope="row">DELETE</td>
                                        <td>id</td>
                                        <td>Int</td>
                                        <td>id tiap hiburan</td>
                                        </tr>
                                        <tr>
                                        <td scope="row">DELETE</td>
                                        <td>nama</td>
                                        <td>String</td>
                                        <td>nama hiburan</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                    </div> 

                    <!-- Response Get All Data -->
                    <h6>Response</h6>
                        
                    <p>Response Success</p>
                    <div class="docs-code-block">
                        <!-- ** Embed github code starts ** -->
                        <script src="https://gist.github.com/fadhilllatif021/0b7ae834b1fa97f70ded498ec407f194.js"></script>
                        <!-- ** Embed github code ends ** -->
                    </div><!--//docs-code-block-->

                    <!-- END Response Get All Data -->
                    <!-- END Request Get All Data -->
                              
                </div>
            </div><!-- End of About Wrapper -->   
        </div>  <!-- End of Container-->        
     </section><!--End of Section -->
     <!-- Section -->


    <section class="pb-0">
        <!-- Container -->
        <div class="container">
            <!-- Pre footer -->
            <div class="pre-footer">
                <ul class="list">
                    <li class="list-head">
                        <h6 class="font-weight-bold">ABOUT US</h6>
                    </li>
                    <li class="list-body">
                        <p>Kelas D4 3A TKJ Angkatan 19.</p>
                    </li>
                </ul>
                <ul class="list">
                    <li class="list-head">
                        <h6 class="font-weight-bold">CONTACT INFO</h6>
                    </li>
                    <li class="list-body">
                        <p>082253241165</p>
                        <p><i class="ti-location-pin"></i> Makassar, Kota Daeng</p>
                        <p><i class="ti-email"></i> tkj19pnup@gmail.com</p>
                    </li>
                </ul> 
            </div><!-- End of Pre footer -->            

            <!-- foooter -->
            <footer class="footer">            
                <p>Copyright <script>document.write(new Date().getFullYear())</script> &copy; <a href="https://github.com/fadhilllatif021">3A TKJ</a></p>
            </footer><!-- End of Footer-->  
            
        </div><!--End of Container -->      
    </section><!-- End of Section -->


    <!-- core  -->
    <script src="assets/vendors/jquery/jquery-3.4.1.js"></script>
    <script src="assets/vendors/bootstrap/bootstrap.bundle.js"></script>

    <!-- bootstrap affix -->
    <script src="assets/vendors/bootstrap/bootstrap.affix.js"></script>

    <!-- Creative Design js -->
    <script src="assets/js/creative-design.js"></script>

     <!-- Page Specific JS -->
    <script src="asset/js/main.js"></script>
    <script src="asset/js/highlight-custom.js"></script> 
    <script src="asset/js/docs.js"></script> 

</body>
</html>
